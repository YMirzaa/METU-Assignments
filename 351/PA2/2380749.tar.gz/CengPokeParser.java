import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.Buffer;
import java.util.ArrayList;
import java.util.Scanner;

public class CengPokeParser {

	public static ArrayList<CengPoke> parsePokeFile(String filename)
	{
		ArrayList<CengPoke> pokeList = new ArrayList<CengPoke>();

		// You need to parse the input file in order to use GUI tables.
		// TODO: Parse the input file, and convert them into CengPokes
		String curline;
		String[] parsed;

		try {
			BufferedReader br = new BufferedReader(new FileReader(filename));
			while((curline = br.readLine()) != null){
				parsed = curline.split("\\t");
				System.out.println(curline);
				pokeList.add(new CengPoke(Integer.parseInt(parsed[1]), parsed[2], parsed[3], parsed[4]));
			}
		}
		catch (Exception e){
			e.printStackTrace();
		}
		return pokeList;
	}
	
	public static void startParsingCommandLine() throws IOException
	{
		// TODO: Start listening and parsing command line -System.in-.
		int valid = 0;
		while(valid == 0){
			Scanner sc = new Scanner(System.in);
			String temp = sc.next();

			if(temp.equals("add")){
				String temp1 = sc.next();
				int temp5 = Integer.parseInt(temp1);

				String temp2 = sc.next();
				String temp3 = sc.next();
				String temp4 = sc.next();

				CengPoke poke = new CengPoke(temp5,temp2,temp3,temp4);

				CengPokeKeeper.addPoke(poke);

			}else if(temp.equals("search")){
				String temp1 = sc.next(); //pokekey
				int temp5 = Integer.parseInt(temp1);

				CengPokeKeeper.searchPoke(temp5);

			}else if(temp.equals("delete")){
				String temp1 = sc.next();
				int temp5 = Integer.parseInt(temp1);

				CengPokeKeeper.deletePoke(temp5);

			}else if(temp.equals("print")){

				CengPokeKeeper.printEverything();

			}else if(temp.equals("quit")){
					break;
			}
		}
		// There are 5 commands:
		// 1) quit : End the app. Print nothing, call nothing.
		// 2) add : Parse and create the poke, and call CengPokeKeeper.addPoke(newlyCreatedPoke).
		// 3) search : Parse the pokeKey, and call CengPokeKeeper.searchPoke(parsedKey).
		// 4) delete: Parse the pokeKey, and call CengPokeKeeper.removePoke(parsedKey).
		// 5) print : Print the whole hash table with the corresponding buckets, call CengPokeKeeper.printEverything().

		// Commands (quit, add, search, print) are case-insensitive.
	}
}
