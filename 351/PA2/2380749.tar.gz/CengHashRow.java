public class CengHashRow {

	// GUI-Based Methods
	// These methods are required by GUI to work properly.
	private CengBucket bucket = null;

	private int rowPrefix;

	public String hashPrefix()
	{
		// TODO: Return row's hash prefix (such as 0, 01, 010, ...)
		String binary = Integer.toBinaryString(rowPrefix);
		int length = CengPokeKeeper.getHashTable().getGlobalDepth() - binary.length();
		if(length>0){
			while(length>0) {
				length-=1;
				binary = "0" + binary;
			}
			return binary;
		}
		return binary;
	}
	
	public CengBucket getBucket()
	{
		// TODO: Return the bucket that the row points at.
		return this.bucket;
	}
	
	public boolean isVisited()
	{
		// TODO: Return whether the row is used while searching.
		return false;		
	}
	
	// Own Methods

	public void setRowPrefix(int prefixNumber){
		this.rowPrefix=prefixNumber;
	}
	public int getRowPrefix(){

		return this.rowPrefix;
	}

	public void setBucket(CengBucket settingBucket){
		this.bucket = settingBucket;
	}
}
