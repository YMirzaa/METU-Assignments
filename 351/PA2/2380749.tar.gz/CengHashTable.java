import java.util.ArrayList;
import java.util.Comparator;
import java.util.Hashtable;

public class CengHashTable {

	public CengBucketList buckets = new CengBucketList();
	private int globalDepth;

	private ArrayList<CengHashRow> arrayBucket;
	private int emptyBucket=0;

	public CengHashTable()
	{
		// TODO: Create a hash table with only 1 row.
		this.arrayBucket = new ArrayList<>();
		CengHashRow newRow = new CengHashRow();
		this.globalDepth=0;

		newRow.setRowPrefix(0);
		this.arrayBucket.add(newRow);

	}

	public void deletePoke(Integer pokeKey)
	{
		// TODO: Empty Implementation
		int log2 =  (int)(Math.log(CengPokeKeeper.getHashMod()) / Math.log(2));

		int modulo = pokeKey % CengPokeKeeper.getHashMod();

		//shift number to get the prefix right
		int shiftedNumber = modulo >> (log2 - this.globalDepth);
		if(this.arrayBucket.get(shiftedNumber).getBucket()!=null) {
			this.arrayBucket.get(shiftedNumber).getBucket().deletePoke(pokeKey);
		}
		printEmptyBucketNumber();
	}

	public void addPoke(CengPoke poke)
	{			
		// TODO: Empty Implementation
		int log2 =  (int)(Math.log(CengPokeKeeper.getHashMod()) / Math.log(2));
		int modulo = poke.pokeKey() % CengPokeKeeper.getHashMod();

		//shift number to get the prefix right
		int shiftedNumber = modulo >> (log2 - this.globalDepth);
		CengBucket theBucket = this.arrayBucket.get(shiftedNumber).getBucket();
		CengHashRow theRow = this.arrayBucket.get(shiftedNumber);

		if(theBucket==null){
			CengBucket newlyCreatedBucket = new CengBucket();
			newlyCreatedBucket.pokeAddNotFull(poke);
			theRow.setBucket(newlyCreatedBucket);
			this.buckets.bucketarray.add(newlyCreatedBucket);
			return;
		}

		//if bucket is full
		if(theBucket.isFull()){

			// if globalDepth == localDepth
			if(theBucket.globalEqualLocal()){
				//increase the size of arrayBucket
				increaseArrayBucketList();
				reOrderBuckets(poke,theBucket,theRow,shiftedNumber,log2);
			}else{
				//just make a new bucket and reorder buckets
				reOrderBuckets(poke, theBucket, theRow, shiftedNumber, log2);
			}

		}else{
			//if bucket is not full just add
			theBucket.pokeAddNotFull(poke);
		}
	}
	
	public void searchPoke(Integer pokeKey)
	{
		// TODO: Empty Implementation
		String search = "\"search\": {\n" ;
		String temp="";
		int valid=0;
		for( int i=0;i!= (1<<this.globalDepth) ; i++){
			for(int j = 0; j!= CengPokeKeeper.getBucketSize(); j++){
				if(arrayBucket.get(i).getBucket() != null &&
						arrayBucket.get(i).getBucket().pokemonArray[j] != null &&
						arrayBucket.get(i).getBucket().pokemonArray[j].pokeKey().equals(pokeKey)){
					temp= temp + printRow(arrayBucket.get(i), 2) + ",\n";
					valid=1;
				}
			}

		}
		if(valid ==1 && temp.length()>2) {
			//delete last ,\n
			temp = temp.substring(0,temp.length()-2);
			temp = temp+ '\n';
		}
		search = search + temp +"}" ;

		System.out.println(search);
	}
	
	public void print()
	{
		// TODO: Empty Implementation
		System.out.println(printTable());
	}

	// GUI-Based Methods
	// These methods are required by GUI to work properly.
	
	public int prefixBitCount()
	{
		// TODO: Return table's hash prefix length.
		return this.globalDepth;
	}
	
	public int rowCount()
	{
		// TODO: Return the count of HashRows in table.
		return 1<<(this.globalDepth);
	}
	
	public CengHashRow rowAtIndex(int index)
	{
		// TODO: Return corresponding hashRow at index.
		return (this.arrayBucket).get(index);
	}
	
	// Own Methods
	public int getGlobalDepth(){
		return this.globalDepth;
	}

	public void increaseArrayBucketList(){
		//wrong totally

		this.globalDepth +=1;
		int temp = (1<<(this.globalDepth)) - (1<<(this.globalDepth-1));
		int temp2 = 1<< this.globalDepth;

		// add new rows to the arrayBucket
		for(int i =0; i!=temp; i++ ){
			CengHashRow addingRow = new CengHashRow();
			this.arrayBucket.add(addingRow);
			//rearrange the new buckets
			//1<<shift + 1

			addingRow.setBucket(this.arrayBucket.get(i).getBucket());

			//set row prefixes
			this.arrayBucket.get(i).setRowPrefix(this.arrayBucket.get(i).getRowPrefix() << 1 );
			addingRow.setRowPrefix( this.arrayBucket.get(i).getRowPrefix() + 1 );

		}
		arrayBucket.sort(Comparator.comparing(CengHashRow::getRowPrefix));

	}
	public void reOrderBuckets(CengPoke poke, CengBucket theBucket, CengHashRow theRow, int shiftedNumber, int log2){
		//decreasee pokemon count

		int hashedNumber;
		int shiftedHashedNumber;

		int temporary = 1<<(globalDepth-1);//(int) Math.pow(2, this.globalDepth -1);

		CengBucket newBucket = new CengBucket();
		this.buckets.bucketarray.add(newBucket);

		//local depth increase
		theBucket.increaseLocalDepth();
		newBucket.setLocalDepth(theBucket.getLocalDepth());

		int valid=0;
		// set the bucket to the new row
		int index = theRow.getRowPrefix();
		if(index % 2==0) {
			index += 1;
		}
		this.arrayBucket.get(index).setBucket(newBucket);

		CengPoke tempPoke;

		for(int i=0; i!=CengPokeKeeper.getBucketSize(); i++){
			tempPoke = theBucket.pokemonArray[i];
			if(tempPoke==null){
				continue;
			}
			// basically check every pokemon inside the bucket and rehash them
			hashedNumber = tempPoke.pokeKey() % CengPokeKeeper.getHashMod();
			shiftedHashedNumber = hashedNumber >> (log2 - this.globalDepth);

			if(shiftedHashedNumber != (index-1) ){
				newBucket.pokeAddNotFull(theBucket.pokemonArray[i]);
				theBucket.pokemonArray[i]=null;
				theBucket.decreasePokemonCount();
			}
		}
		//last add the poke // if its empty
		// basically check every pokemon inside the bucket and rehash them
		hashedNumber = poke.pokeKey() % CengPokeKeeper.getHashMod();
		shiftedHashedNumber = hashedNumber >> (log2 - this.globalDepth);

		if(shiftedHashedNumber != (index-1) ){
			if(newBucket.isFull()){
				this.addPoke(poke);
			}else{
				newBucket.pokeAddNotFull(poke);
			}
		}else{
			if(theBucket.isFull()){
				this.addPoke(poke);
			}else{
				theBucket.pokeAddNotFull(poke);
			}
		}
	}

	public String printPokemon(CengPoke pokemon, int repeatCount){
		String hashValue =pokemon.hashValue();
		String numberOfTabs = "\t".repeat(repeatCount);
		String minesNumberTabs = "\t".repeat(repeatCount-1);

		String poke = minesNumberTabs+"\"poke\": {\n" +
				numberOfTabs+"\"hash\": " + hashValue + ",\n" +
				numberOfTabs+ "\"pokeKey\": " + Integer.toString(pokemon.pokeKey()) + ",\n" +
				numberOfTabs+ "\"pokeName\": " + pokemon.pokeName() + ",\n" +
				numberOfTabs+ "\"pokePower\": " + pokemon.pokePower() + ",\n" +
				numberOfTabs+ "\"pokeType\": " + pokemon.pokeType() + "\n" +
				minesNumberTabs+"}";
		return poke;

	}

	public String printBucket(CengBucket printedBucket, int repeatCount){

		String numberOfTabs = "\t".repeat(repeatCount);
		String minusRepeatCount = "\t".repeat(repeatCount-1);
		int temmp;
		if(printedBucket!=null){
			temmp = printedBucket.getLocalDepth();
		}else{
			temmp=0;
		}


		String bucket = minusRepeatCount + "\"bucket\": {\n" +
				numberOfTabs + "\"hashLength\": " + Integer.toString(temmp) +",\n" +
				numberOfTabs + "\"pokes\": [\n";
		String temp="";

		//add \t\t to pokes
		int temporaray=0;
		for( int i=0;i!=CengPokeKeeper.getBucketSize(); i++){
			if(printedBucket!=null && printedBucket.pokemonArray[i]!= null){
				temp= temp + printPokemon(printedBucket.pokemonArray[i], repeatCount+2) + ",\n";
				temporaray=1;
			}
		}
		//delete last ,
		if(temp.length()>2) {
			temp = temp.substring(0, temp.length() - 2);

		}
		if(temporaray==1){
			temp = temp + '\n';
		}

		String anotherTemp = numberOfTabs +"]\n" + minusRepeatCount + "}\n";
		bucket = bucket + temp +anotherTemp ;

		return bucket;
	}
	public String printRow(CengHashRow printedRow, int repeatCount){

		String numberOfTabs = "\t".repeat(repeatCount);
		String minusRepeatCount = "\t".repeat(repeatCount-1);

		String row = minusRepeatCount + "\"row\": {\n" +
				numberOfTabs + "\"hashPref\": " + printedRow.hashPrefix() +",\n";
		String temp="";

		temp= temp + printBucket(printedRow.getBucket(), repeatCount+1) ;

		String anotherTemp =  minusRepeatCount + "}";
		row = row + temp +anotherTemp ;

		return row;
	}
	public String printTable(){

		String table = "\"table\": {\n" ;
		String temp="";

		for( int i=0;i!= (1<<this.globalDepth) ; i++){
			temp= temp + printRow(arrayBucket.get(i), 2) + ",\n";
		}

		//delete last ,
		if(temp.length()>2) {
			temp = temp.substring(0, temp.length() - 2);

		}
		temp = temp + '\n';

		table = table + temp +"}" ;

		return table;
	}

	public int getEmptyBucket(){

		for( int i=0;i!= (1<<this.globalDepth) ; i++){
			if(arrayBucket.get(i).getBucket() != null){
				if(arrayBucket.get(i).getBucket().isEmpty()){
					this.emptyBucket +=1;
				}
			}
		}
		return this.emptyBucket;
	}
	public void printEmptyBucketNumber(){

		String emptyBucket = "\"delete\": {\n" +
				"\t"+"\"emptyBucketNum\": " + Integer.toString(getEmptyBucket()) + "\n" +
				"}";
		System.out.println(emptyBucket);
	}

}
