import java.util.ArrayList;

public class CengBucketList {

	public ArrayList<CengBucket> bucketarray = new ArrayList<>();

	public CengBucketList()
	{
		// TODO: Empty Implementation
	}

	public void deletePoke(Integer pokeKey)
	{
		// TODO: Empty Implementation
	}

	public void addPoke(CengPoke poke)
	{
		// TODO: Empty Implementation
	}
	
	public void searchPoke(Integer pokeKey)
	{
		// TODO: Empty Implementation
	}
	
	public void print()
	{
		// TODO: Empty Implementation
	}
	
	// GUI-Based Methods
	// These methods are required by GUI to work properly.
	
	public int bucketCount()
	{
		// TODO: Return all bucket count.
		return this.bucketarray.size();
	}
	
	public CengBucket bucketAtIndex(int index)
	{
		// TODO: Return corresponding bucket at index.
		return this.bucketarray.get(index);
	}
	
	// Own Methods
}
