import java.util.ArrayList;
import java.util.Arrays;

public class CengBucket {

	// GUI-Based Methods
	// These methods are required by GUI to work properly.
	private int bucketSize = CengPokeKeeper.getBucketSize();
	public CengPoke[] pokemonArray = new CengPoke[bucketSize];

	private int pokemonCount = 0; //use as index as well
	private int localDepth = 0;

	public int pokeCount() {
		return this.pokemonCount;
	}

	public CengPoke pokeAtIndex(int index) {
		// TODO: Return the corresponding pokemon at the index.
		return this.pokemonArray[index];
	}

	public int getHashPrefix() {
		// TODO: Return hash prefix length.
		return CengPokeKeeper.getHashTable().getGlobalDepth();
	}

	public Boolean isVisited() {
		// TODO: Return whether the bucket is found while searching.
		return false;
	}

	// Own Methods
	public void setLocalDepth(int newLocalDepth){
		this.localDepth=newLocalDepth;
	}
	public int getLocalDepth(){
		return this.localDepth;
	}
	public void increaseLocalDepth() {
		this.localDepth += 1;
	}

	public boolean isFull() {
		return this.pokemonCount == this.bucketSize;
	}

	public boolean globalEqualLocal() {
		return CengPokeKeeper.getHashTable().getGlobalDepth() == this.localDepth;
	}

	// add pokemon
	public void pokeAddNotFull(CengPoke poke) {
		for (int i = 0; i != this.bucketSize; i++){
			if (this.pokemonArray[i]==null){
				this.pokemonArray[i] = poke;
				this.pokemonCount+=1;
				return;
			}
		}
	}

	public void deletePoke(int pokeKey){
		for(int i=0; i!=this.bucketSize; i++){
			if(this.pokemonArray[i] != null && this.pokemonArray[i].pokeKey() == pokeKey){
				this.pokemonArray[i] = null;
				this.pokemonCount-=1;
				return;
			}
		}
	}
	public void decreasePokemonCount(){
		this.pokemonCount-=1;
	}
	public boolean isEmpty(){
		return this.pokemonCount==0;
	}
}

