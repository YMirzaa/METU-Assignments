package ceng.ceng351.cengvacdb;
import ceng.ceng351.cengvacdb.*;

import ceng.ceng351.cengvacdb.QueryResult.UserIDuserNameAddressResult;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.DatabaseMetaData;
import java.text.DecimalFormat;
import java.util.Vector;

public class CENGVACDB implements ceng.ceng351.cengvacdb.ICENGVACDB {
    private static String user = "e2380749"; // TODO: Your userName
    private static String password = "Jnx84BytdLw!"; //  TODO: Your password
    private static String host = "144.122.71.121"; // host name
    private static String database = "db2380749"; // TODO: Your database name
    private static int port = 8080; // port

    private static Connection connection = null;

    String url = "jdbc:mysql://" + host + ":" + port + "/" + database + "?useSSL=false";
    @Override
    public void initialize() {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection =  DriverManager.getConnection(url, user, password);
        }
        catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    @Override
    public int createTables() {
        ResultSet rs = null;

        try(Statement statement = connection.createStatement();){
            int number_of_tables=0;
            DatabaseMetaData dbm = connection.getMetaData();

            ResultSet tables = dbm.getTables(null, null, "User", null);
            if (!tables.next()) {
                //System.out.println("Creating the User Table...");

                String UserCreate = "CREATE TABLE User" +
                        "(userID INTEGER," +
                        "userName VARCHAR(30)," +
                        "age INTEGER," +
                        "address VARCHAR(150)," +
                        "password VARCHAR(30)," +
                        "status VARCHAR(15)," +
                        "PRIMARY KEY (userID));" ;
                statement.executeUpdate(UserCreate);
                number_of_tables+=1;
            }

            tables = dbm.getTables(null, null, "Vaccine", null);
            if (!tables.next()) {
                //Vaccine
                //System.out.println("Creating the Vaccine Table...");
                String VaccineCreate = "CREATE TABLE Vaccine" +
                        "(code INTEGER," +
                        "vaccinename VARCHAR(30)," +
                        "type VARCHAR(30)," +
                        "PRIMARY KEY (code));" ;
                statement.executeUpdate(VaccineCreate);
                number_of_tables+=1;
            }

            tables = dbm.getTables(null, null, "Vaccination", null);
            if (!tables.next()) {
                //System.out.println("Creating the Vaccination Table...");
                //Vaccination
                String VaccinationCreate = "CREATE TABLE Vaccination" +
                        "(code INTEGER," +
                        "userID INTEGER," +
                        "dose INTEGER," +
                        "vacdate DATE," +
                        "PRIMARY KEY (code, userID,dose)," +
                        "FOREIGN KEY (code) REFERENCES Vaccine(code) ON DELETE CASCADE ON UPDATE CASCADE," +
                        "FOREIGN KEY (userID) REFERENCES User(userID) ON DELETE CASCADE ON UPDATE CASCADE);";
                statement.executeUpdate(VaccinationCreate);
                number_of_tables+=1;
            }

            tables = dbm.getTables(null, null, "AllergicSideEffect", null);
            if (!tables.next()) {
                //System.out.println("Creating the AllergicSideEffect Table...");
                //AllergicSideEffect
                String AllergicSideEffectCreate = "CREATE TABLE AllergicSideEffect" +
                        "(effectcode INTEGER," +
                        "effectname VARCHAR(50)," +
                        "PRIMARY KEY (effectcode));";
                statement.executeUpdate(AllergicSideEffectCreate);
                number_of_tables+=1;
            }

            tables = dbm.getTables(null, null, "Seen", null);
            if (!tables.next()) {
                //System.out.println("Creating the Seen Table...");
                //Seen
                String SeenCreate = "CREATE TABLE Seen" +
                        "(effectcode INTEGER," +
                        "code INTEGER," +
                        "userID INTEGER," +
                        "date DATE," +
                        "degree VARCHAR(30)," +
                        "PRIMARY KEY (effectcode,code,userID)," +
                        "FOREIGN KEY (effectcode) REFERENCES AllergicSideEffect(effectcode) ON DELETE CASCADE ON UPDATE CASCADE," +
                        "FOREIGN KEY (code) REFERENCES Vaccination(code) ON DELETE CASCADE ON UPDATE CASCADE," +
                        "FOREIGN KEY (userID) REFERENCES User(userID) ON DELETE CASCADE ON UPDATE CASCADE);";
                statement.executeUpdate(SeenCreate);
                number_of_tables+=1;
            }

            return number_of_tables;
        }
        catch (SQLException e){
            e.printStackTrace();
        }

        return 0;
    }

    @Override
    public int dropTables() {
        ResultSet rs = null;
        try(Statement statement = connection.createStatement();){
            int number_of_tables=0;
            String sql;
            DatabaseMetaData dbm = connection.getMetaData();
            //if users droped drop seen - vaccination - user
            //vaccine drop , seen - vaccination - vaccine
            //vaccination drop , seen - vaccination
            //allergicsideeffect drop, seen - allergic
            //seen drop, seen
            ResultSet tables = dbm.getTables(null, null, "User", null);
            if (tables.next()) {

                tables = dbm.getTables(null, null, "Seen", null);
                if(tables.next()){
                    //System.out.println("Droping the Seen Table...");
                    sql = "DROP TABLE Seen;" ;
                    statement.executeUpdate(sql);
                    number_of_tables+=1;
                }
                //user table
                tables = dbm.getTables(null, null, "Vaccination", null);
                if(tables.next()){
                    //System.out.println("Droping the Vaccination Table...");
                    sql = "DROP TABLE Vaccination;" ;
                    statement.executeUpdate(sql);
                    number_of_tables+=1;
                }
                //System.out.println("Droping the User Table...");
                String UserDrop = "DROP TABLE User;" ;
                statement.executeUpdate(UserDrop);
                number_of_tables+=1;
            }

            tables = dbm.getTables(null, null, "Vaccine", null);
            if (tables.next()) {

                tables = dbm.getTables(null, null, "Seen", null);
                if(tables.next()){
                    //System.out.println("Droping the Seen Table...");
                    sql = "DROP TABLE Seen;" ;
                    statement.executeUpdate(sql);
                    number_of_tables+=1;
                }
                //user table
                tables = dbm.getTables(null, null, "Vaccination", null);
                if(tables.next()){
                    //System.out.println("Droping the Vaccination Table...");
                    sql = "DROP TABLE Vaccination;" ;
                    statement.executeUpdate(sql);
                    number_of_tables+=1;
                }
                //System.out.println("Droping the Vaccine Table...");
                String VaccineDrop = "DROP TABLE Vaccine;" ;
                statement.executeUpdate(VaccineDrop);
                number_of_tables+=1;
            }

            tables = dbm.getTables(null, null, "Vaccination", null);
            if (tables.next()) {

                tables = dbm.getTables(null, null, "Seen", null);
                if(tables.next()){
                    //System.out.println("Droping the Seen Table...");
                    sql = "DROP TABLE Seen;";
                    statement.executeUpdate(sql);
                    number_of_tables+=1;
                }
                //System.out.println("Droping the Vaccination Table...");
                String VaccinationDrop = "DROP TABLE Vaccination;" ;
                statement.executeUpdate(VaccinationDrop);
                number_of_tables+=1;
            }

            tables = dbm.getTables(null, null, "AllergicSideEffect", null);
            if (tables.next()) {
                tables = dbm.getTables(null, null, "Seen", null);
                if(tables.next()){
                    //System.out.println("Droping the Seen Table...");
                    sql = "DROP TABLE Seen;" ;
                    statement.executeUpdate(sql);
                    number_of_tables+=1;
                }
                //System.out.println("Droping the AllergicSideEffect Table...");
                String AllergicSideEffectDrop = "DROP TABLE AllergicSideEffect;" ;
                statement.executeUpdate(AllergicSideEffectDrop);
                number_of_tables+=1;
            }

            tables = dbm.getTables(null, null, "Seen", null);
            if (tables.next()) {
                //System.out.println("Droping the Seen Table...");
                String SeenDrop = "DROP TABLE Seen;" ;
                statement.executeUpdate(SeenDrop);
                number_of_tables+=1;
            }


            return number_of_tables;
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public int insertUser(User[] users) {

        ResultSet rs = null;

        int lenght = users.length ;
        int number_of_success=0;
        String insert;
        try(Statement statement = connection.createStatement();){
            for(int i=0; i!=lenght; i++){

                insert = "INSERT INTO User(UserID, UserName, Age, Address, Password, Status) " +
                        "VALUES("+
                         users[i].getUserID()+
                        ", '" + users[i].getUserName() +
                        "', " + users[i].getAge() +
                        ", '" + users[i].getAddress() +
                        "', '" + users[i].getPassword() +
                        "', '" + users[i].getStatus() +
                        "');" ;
                if(statement.executeUpdate(insert)!=0){
                    number_of_success+=1;
                }
            }
            return number_of_success;
        }
        catch (SQLException e){
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public int insertAllergicSideEffect(AllergicSideEffect[] sideEffects) {

        int lenght = sideEffects.length ;
        int number_of_success=0;
        String insert;
        try(Statement statement = connection.createStatement();){
            for(int i=0; i!=lenght; i++){

                insert = "INSERT INTO AllergicSideEffect(effectcode, effectname) " +
                        "VALUES("+
                        sideEffects[i].getEffectCode()+
                        ", '" + sideEffects[i].getEffectName() +
                        "');" ;
                if(statement.executeUpdate(insert)!=0){
                    number_of_success+=1;
                }
            }
            return number_of_success;
        }
        catch (SQLException e){
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public int insertVaccine(Vaccine[] vaccines) {
        ResultSet rs = null;

        int lenght = vaccines.length ;
        int number_of_success=0;
        String insert;
        try(Statement statement = connection.createStatement();){
            for(int i=0; i!=lenght; i++){

                insert = "INSERT INTO Vaccine(code, vaccinename, type) " +
                        "VALUES("+
                        vaccines[i].getCode()+
                        ", '" + vaccines[i].getVaccineName() +
                        "', '" + vaccines[i].getType() +
                        "');" ;
                if(statement.executeUpdate(insert)!=0){
                    number_of_success+=1;
                }
            }
            return number_of_success;
        }
        catch (SQLException e){
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public int insertVaccination(Vaccination[] vaccinations) {
        ResultSet rs = null;

        int lenght = vaccinations.length ;
        int number_of_success=0;
        String insert;
        try(Statement statement = connection.createStatement();){
            for(int i=0; i!=lenght; i++){


                insert = "INSERT INTO Vaccination(code, userID, dose, vacdate) " +
                        "VALUES("+
                        vaccinations[i].getCode()+
                        ", " + vaccinations[i].getUserID() +
                        ", " + vaccinations[i].getDose() +
                        ", '" + vaccinations[i].getVacdate() +
                        "');" ;

                if(statement.executeUpdate(insert)!=0){
                    number_of_success+=1;
                }
            }
            return number_of_success;
        }
        catch (SQLException e){
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public int insertSeen(Seen[] seens) {
        ResultSet rs = null;

        int lenght = seens.length ;
        int number_of_success=0;
        String insert;
        try(Statement statement = connection.createStatement();){
            for(int i=0; i!=lenght; i++){

                insert = "INSERT INTO Seen(effectcode, code, userID, date, degree) " +
                        "VALUES("+
                        seens[i].getEffectcode()+
                        ", " + seens[i].getCode() +
                        ", " + seens[i].getUserID() +
                        ", '" + seens[i].getDate() +
                        "', '" + seens[i].getDegree() +
                        "');" ;
                if(statement.executeUpdate(insert)!=0){
                    number_of_success+=1;
                }
            }
            return number_of_success;
        }
        catch (SQLException e){
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public Vaccine[] getVaccinesNotAppliedAnyUser() {
        ResultSet rs = null;

        String sql;
        try(Statement statement = connection.createStatement();){
            sql = "SELECT v.code, v.vaccinename, v.type " +
                    "FROM Vaccine v " +
                    "WHERE v.code " +
                    "NOT IN(SELECT DISTINCT vac.code " +
                    "FROM Vaccine vac, Vaccination cnt " +
                    "WHERE vac.code = cnt.code) "+
                    "ORDER BY v.code ASC;" ;

            rs = statement.executeQuery(sql);

            int size =0;
            if (rs != null)
            {
                rs.last();    // moves cursor to the last row
                size = rs.getRow(); // get row id
                Vaccine [] arr = new Vaccine[size];
                rs.beforeFirst();
                for(int i=0; rs.next(); i++){
                    int code = rs.getInt(1);
                    String vaccinename = rs.getString(2);
                    String type = rs.getString(3);
                    arr[i] = new Vaccine(code, vaccinename, type);
                }
                return arr;
            }else{
                return new Vaccine[0];
            }

        }
        catch (SQLException e){
            e.printStackTrace();
        }

        return new Vaccine[0];
    }

    @Override
    public QueryResult.UserIDuserNameAddressResult[] getVaccinatedUsersforTwoDosesByDate(String vacdate) {
        ResultSet rs = null;

        String sql;
        try(Statement statement = connection.createStatement();){

            sql = "SELECT DISTINCT u.userID, u.userName, u.address " +
                    "FROM User u, Vaccination v " +
                    "WHERE u.userID =v.userID AND v.vacdate > '" + vacdate+
                    "' GROUP BY u.userID " +
                    "HAVING COUNT(*)=2 AND MAX(dose)=2 " +
                    " ORDER BY u.userID ASC;" ;
            rs = statement.executeQuery(sql);

            int size =0;
            if (rs != null)
            {
                rs.last();    // moves cursor to the last row
                size = rs.getRow(); // get row id
                QueryResult.UserIDuserNameAddressResult [] arr = new QueryResult.UserIDuserNameAddressResult[size];
                rs.beforeFirst();

                for(int i=0; rs.next(); i++){
                    int userid = rs.getInt(1);
                    String id = Integer.toString(userid);
                    String username = rs.getString(2);
                    String address = rs.getString(3);
                    arr[i] = new QueryResult.UserIDuserNameAddressResult(id, username, address);
                }
                return arr;
            }else{
                return new QueryResult.UserIDuserNameAddressResult[0];
            }

        }
        catch (SQLException e){
            e.printStackTrace();
        }
        return new QueryResult.UserIDuserNameAddressResult[0];
    }

    @Override
    public Vaccine[] getTwoRecentVaccinesDoNotContainVac() {
        ResultSet rs = null;

        String sql;
        try(Statement statement = connection.createStatement();){

            sql = "SELECT DISTINCT a.code, a.vaccinename, a.type " +
                    "FROM " +
                        "(SELECT DISTINCT t.code, t.vaccinename, t.type, t.vacdate " +
                        "FROM " +
                            "( SELECT DISTINCT u.code, u.vaccinename, u.type, MAX(v.vacdate) as vacdate " +
                            "FROM Vaccine u, Vaccination v " +
                            "WHERE u.code =v.code AND u.vaccinename NOT LIKE '%vac%' " +
                            "GROUP BY u.code " +
                            ") AS t" +
                        " ORDER BY DATE(t.vacdate) DESC " +
                        "LIMIT 2) AS a " +
                    "ORDER BY a.code ASC;" ;
            rs = statement.executeQuery(sql);

            int size =0;
            if (rs != null)
            {
                rs.last();    // moves cursor to the last row
                size = rs.getRow(); // get row id
                Vaccine [] arr = new Vaccine[size];
                rs.beforeFirst();

                for(int i=0; rs.next(); i++){
                    int code = rs.getInt(1);
                    String vaccinename = rs.getString(2);
                    String type = rs.getString(3);
                    arr[i] = new Vaccine(code, vaccinename, type);
                }
                return arr;
            }else{
                return new Vaccine[0];
            }

        }
        catch (SQLException e){
            e.printStackTrace();
        }
        return new Vaccine[0];
    }

    @Override
    public QueryResult.UserIDuserNameAddressResult[] getUsersAtHasLeastTwoDoseAtMostOneSideEffect() {
        ResultSet rs = null;

        String sql;
        try(Statement statement = connection.createStatement();){

            sql = " SELECT DISTINCT p.userID, p.userName, p.address " +
                    " FROM User p" +
                    " WHERE p.userID IN " +

                            "(SELECT DISTINCT y.userID " +
                            " FROM User y " +
                            " WHERE y.userID IN " +

                                " (SELECT DISTINCT t.userID " +
                                " FROM User t, Vaccination v" +
                                " WHERE t.userID = v.userID" +
                                " GROUP BY t.userID " +
                                " HAVING COUNT(*)>=2) AND y.userID NOT IN" +

                            "(SELECT DISTINCT u.userID " +
                            " FROM User u, Seen s " +
                            " WHERE u.userID = s.userID " +
                            " GROUP BY u.userID " +
                            " HAVING COUNT(*) > 1)) " +

                    " ORDER BY p.userID ASC;" ;
            rs = statement.executeQuery(sql);

            int size =0;
            if (rs != null)
            {
                rs.last();    // moves cursor to the last row
                size = rs.getRow(); // get row id
                QueryResult.UserIDuserNameAddressResult [] arr = new QueryResult.UserIDuserNameAddressResult[size];
                rs.beforeFirst();

                for(int i=0; rs.next(); i++){
                    int userid = rs.getInt(1);
                    String id = Integer.toString(userid);
                    String username = rs.getString(2);
                    String address = rs.getString(3);
                    arr[i] = new QueryResult.UserIDuserNameAddressResult(id, username, address);
                }
                return arr;
            }else{
                return new QueryResult.UserIDuserNameAddressResult[0];
            }

        }
        catch (SQLException e){
            e.printStackTrace();
        }

        return new QueryResult.UserIDuserNameAddressResult[0];
    }

    @Override
    public QueryResult.UserIDuserNameAddressResult[] getVaccinatedUsersWithAllVaccinesCanCauseGivenSideEffect(String effectname) {
        ResultSet rs = null;

        String sql;
        try(Statement statement = connection.createStatement();){

            sql = "SELECT DISTINCT u.userid, u.username, u.address " +
                    " FROM User u, Vaccination v " +
                    " WHERE u.userid = v.userID AND NOT EXISTS  " +
                        "(SELECT s.code " +
                        " FROM AllergicSideEffect al, Seen s " +
                        " WHERE al.effectname = '"+ effectname +"' AND al.effectcode = s.effectcode AND NOT EXISTS " +
                            "(SELECT vac.code " +
                            " FROM Vaccination vac " +
                            " WHERE vac.code = v.code AND v.code = s.code))" +
                    " ORDER BY u.userID ASC;" ;

            rs = statement.executeQuery(sql);

            int size =0;
            if (rs != null)
            {
                rs.last();    // moves cursor to the last row
                size = rs.getRow(); // get row id
                QueryResult.UserIDuserNameAddressResult [] arr = new QueryResult.UserIDuserNameAddressResult[size];
                rs.beforeFirst();

                for(int i=0; rs.next(); i++){
                    int userid = rs.getInt(1);
                    String id = Integer.toString(userid);
                    String username = rs.getString(2);
                    String address = rs.getString(3);
                    arr[i] = new QueryResult.UserIDuserNameAddressResult(id, username, address);
                }
                return arr;
            }else{
                return new QueryResult.UserIDuserNameAddressResult[0];
            }

        }
        catch (SQLException e){
            e.printStackTrace();
        }
        return new QueryResult.UserIDuserNameAddressResult[0];
    }

    @Override
    public QueryResult.UserIDuserNameAddressResult[] getUsersWithAtLeastTwoDifferentVaccineTypeByGivenInterval(String startdate, String enddate) {
        ResultSet rs = null;

        String sql;
        try(Statement statement = connection.createStatement();){

            sql = "SELECT DISTINCT u.userid, u.username, u.address " +
                    "FROM User u, Vaccination v,User us,Vaccination vac  " +
                    "WHERE u.userID = us.userID AND v.code<>vac.code AND v.userID = u.userID AND us.userID = vac.userID " +
                    "AND vac.userID = v.userID " +
                    " AND vac.vacdate >'"+ startdate + "' AND vac.vacdate <'"+ enddate + "'" +
                    " AND v.vacdate >'"+ startdate + "' AND v.vacdate <'"+ enddate + "' " +
            " ORDER BY u.userID ASC;" ;

            rs = statement.executeQuery(sql);

            int size =0;
            if (rs != null)
            {
                rs.last();    // moves cursor to the last row
                size = rs.getRow(); // get row id
                QueryResult.UserIDuserNameAddressResult [] arr = new QueryResult.UserIDuserNameAddressResult[size];
                rs.beforeFirst();

                for(int i=0; rs.next(); i++){
                    int userid = rs.getInt(1);
                    String id = Integer.toString(userid);
                    String username = rs.getString(2);
                    String address = rs.getString(3);
                    arr[i] = new QueryResult.UserIDuserNameAddressResult(id, username, address);
                }
                return arr;
            }else{
                return new QueryResult.UserIDuserNameAddressResult[0];
            }

        }
        catch (SQLException e){
            e.printStackTrace();
        }
        return new QueryResult.UserIDuserNameAddressResult[0];
    }

    @Override
    public AllergicSideEffect[] getSideEffectsOfUserWhoHaveTwoDosesInLessThanTwentyDays() {
        ResultSet rs = null;

        String sql;
        try(Statement statement = connection.createStatement();){

            sql = "SELECT DISTINCT al.effectcode, al.effectname " +
                    "FROM AllergicSideEffect al, Seen s, User sl, Vaccination v, User us, Vaccination vac " +
                    "WHERE s.effectcode=al.effectcode " +
                    " AND sl.userID=us.userID AND s.userID = us.userID AND v.userID=sl.userID AND v.userID=vac.userID " +
                    " AND v.vacdate<>vac.vacdate AND v.code = vac.code AND v.dose<>vac.dose " +
                    " AND v.dose> vac.dose " +
                    " AND  (SELECT DATEDIFF(v.vacdate,vac.vacdate )) < 20 " +
                    " ORDER BY al.effectcode ASC;" ;

            rs = statement.executeQuery(sql);

            int size =0;
            if (rs != null)
            {
                rs.last();    // moves cursor to the last row
                size = rs.getRow(); // get row id
                AllergicSideEffect [] arr = new AllergicSideEffect[size];
                rs.beforeFirst();

                for(int i=0; rs.next(); i++){
                    int code = rs.getInt(1);
                    String name = rs.getString(2);
                    arr[i] = new AllergicSideEffect(code, name);
                }
                return arr;
            }else{
                return new AllergicSideEffect[0];
            }

        }
        catch (SQLException e){
            e.printStackTrace();
        }
        return new AllergicSideEffect[0];
    }

    @Override
    public double averageNumberofDosesofVaccinatedUserOverSixtyFiveYearsOld() {
        ResultSet rs = null;

        String sql;
        try(Statement statement = connection.createStatement();){

            sql = "SELECT DISTINCT AVG(t.maxdose)" +
                    "FROM (SELECT MAX(v.dose) as maxdose " +
                    " FROM User u,Vaccination v" +
                    " WHERE u.age >65 AND u.userID = v.userID " +
                    " GROUP BY u.userID) as t " +
                    " ;" ;

            rs = statement.executeQuery(sql);

            if (rs != null)
            {

                rs.beforeFirst();
                float number=0;
                for(int i=0; rs.next(); i++){
                    number = rs.getFloat(1);
                }
                return number;
            }else{
                return 0;
            }

        }
        catch (SQLException e){
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public int updateStatusToEligible(String givendate) {
        ResultSet rs = null;

        String sql;
        try(Statement statement = connection.createStatement();){

            sql = "UPDATE User u " +
                    " SET u.status ='Eligible' " +
                    " WHERE u.status = 'Not_Eligible' AND u.userID IN " +
                        "(SELECT DISTINCT v.userID " +
                        " FROM Vaccination v " +
                        " WHERE (SELECT DATEDIFF('"+ givendate +"',v.vacdate )) >= 120 AND" +
                        " v.userID = u.userID AND v.vacdate =  " +
                            "(SELECT DISTINCT MAX(vac.vacdate) " +
                            " FROM Vaccination vac " +
                            " WHERE vac.userID = u.userID AND v.userID = vac.userID AND v.userID = u.userID ) )" +
                    " ;" ;

            int number = statement.executeUpdate(sql);

            if (number!=0)
            {
                return number;
            }else{
                return 0;
            }

        }
        catch (SQLException e){
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public Vaccine deleteVaccine(String vaccineName) {
        ResultSet rs = null;

        String sql;
        try(Statement statement = connection.createStatement();){
            sql = "SELECT v.code, v.vaccinename, v.type " +
                    " FROM Vaccine v" +
                    " WHERE  v.vaccinename = '" +vaccineName+"';" ;

            rs = statement.executeQuery(sql);

            sql = "DELETE FROM Vaccine v" +
                    " WHERE  v.vaccinename = '" +vaccineName+"';" ;
            //int number = statement.executeUpdate(sql);
            if (rs!=null )
            {
                //rs.first();
                rs.next();
                int code = rs.getInt(1);
                String vaccinename = rs.getString(2);
                String type = rs.getString(3);
                Vaccine arr = new Vaccine(code, vaccinename, type);
                return arr;
            }
            else{
                return null;
            }

        }
        catch (SQLException e){
            e.printStackTrace();
        }
        return null;
    }
}
